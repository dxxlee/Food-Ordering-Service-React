import { useState } from "react";

export const ProductPreviewCard = ({ product, updateCart }) => {
    const [isLoading, setIsLoading] = useState(false);

    const addProduct = async () => {
        setIsLoading(true);
        try {
            const response = await fetch("http://localhost:8080/api/cart/add", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${sessionStorage.getItem("Auth token")}`,
                },
                body: JSON.stringify({
                    productId: product._id,
                    name: product.name,
                    price: product.price
                }),
            });

            if (response.ok) {
                const updatedCart = await response.json();
                updateCart(updatedCart.items);
            } else {
                const error = await response.json();
                console.error("Error adding to cart:", error.message);
            }
        } catch (err) {
            console.error("Something went wrong:", err);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="w-full p-4 m-2 rounded text-white bg-gradient-to-b from-slate-600 to-transparent text-center">
            <img src={product.imageUrl} alt={product.name} />
            <h2 className="pb-2 text-lg">{product.name}</h2>
            <p className="mb-2 h-20 line-clamp-4">{product.description}</p>
            <button
                onClick={addProduct}
                className="bg-yellow-400 hover:bg-yellow-500 rounded-full w-10 h-10 flex items-center justify-center text-lg"
                disabled={isLoading}
            >
                {isLoading ? "..." : "+"}
            </button>
        </div>
    );
};
