import { useSelector } from "react-redux";
import { getAddress } from "../stores/userInfo/addressSlice";
import { useNavigate } from "react-router-dom";
import Button from "./elements/Button";

const PaymentForm = ({ cart, setCart }) => {
  const address = useSelector(getAddress);
  const navigate = useNavigate();

  const handlePayment = async () => {
    try {
      const order = {
        orderItems: cart,
        shippingAddress: address,
        totalPrice: cart.reduce((sum, item) => sum + item.price * item.amount, 0),
      };

      const response = await fetch("http://localhost:8080/api/orders/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${sessionStorage.getItem("Auth token")}`,
        },
        body: JSON.stringify(order),
      });

      if (response.ok) {
        setCart([]); // Очистить корзину на фронте
        navigate("/payment-success");
      } else {
        const error = await response.json();
        console.error("Error creating order:", error.message);
      }
    } catch (err) {
      console.error("Something went wrong:", err);
    }
  };

  return (
    <div className="w-full flex flex-col items-center">
      <Button onClick={handlePayment}>Pay Now</Button>
    </div>
  );
};

export default PaymentForm;
