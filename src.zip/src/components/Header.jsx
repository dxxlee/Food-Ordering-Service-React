import { Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import foody from "../assets/images/foody.png";
import cartIcon from "../assets/icons/cart.svg";

export const Header = ({ cartCount }) => {
  const navigate = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userName, setUserName] = useState("");

  useEffect(() => {
    const token = sessionStorage.getItem("Auth token");
    const user = sessionStorage.getItem("User");

    if (token && user) {
      setIsLoggedIn(true);
      setUserName(JSON.parse(user).name);
    }
  }, []);

  const handleLogout = () => {
    sessionStorage.removeItem("Auth token");
    sessionStorage.removeItem("User");
    setIsLoggedIn(false);
    navigate("/login");
    window.location.reload(); // Обновление после выхода
  };

  return (
    <nav className="bg-black text-white p-4">
      <div className="w-full container mx-auto flex flex-wrap items-center justify-between">
        {/* Логотип */}
        <div className="logo-wrapper pl-4 flex items-center">
          <Link to="/" className="text-white font-bold text-2xl lg:text-4xl">
            <img src={foody} alt="logo" className="w-40 h-40 object-cover" />
          </Link>
        </div>

        {/* Навигационное меню */}
        <div className="nav-menu-wrapper flex items-center space-x-10">
          <Link to="/" className="text-xl hover:text-gray-400 transition">Home</Link>
          <Link to="#about" className="text-xl hover:text-gray-400 transition">About</Link>
          <Link to="/orders" className="text-xl">My Orders</Link> {/* Новая кнопка */}
        </div>
        

        {/* Корзина и логин/выход */}
        <div className="flex items-center space-x-4">
          <Link to="/cart" className="relative">
            <img src={cartIcon} alt="cart" />
            {cartCount > 0 && (
              <div className="absolute -top-1 -right-1 bg-yellow-400 text-white rounded-full px-2 py-1 text-sm">
                {cartCount}
              </div>
            )}
          </Link>

          {isLoggedIn ? (
            <>
              <span className="text-lg">Welcome, {userName}!</span>
              <button
                onClick={handleLogout}
                className="bg-red-500 px-3 py-1 rounded hover:bg-red-600 transition"
              >
                Log Out
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="text-lg hover:text-gray-400 transition">Log In</Link>
              <Link to="/register" className="text-lg hover:text-gray-400 transition">Sign Up</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};
