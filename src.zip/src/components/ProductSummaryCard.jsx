export const ProductSummaryCard = ({ product, updateCart }) => {
    const handleIncrement = async () => {
        try {
            const response = await fetch("http://localhost:8080/api/cart/add", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${sessionStorage.getItem("Auth token")}`,
                },
                body: JSON.stringify({
                    productId: product.product,
                    name: product.name,
                    price: product.price
                }),
            });

            if (response.ok) {
                const updatedCart = await response.json();
                updateCart(updatedCart.items);
            }
        } catch (err) {
            console.error("Error updating cart:", err);
        }
    };

    const handleDecrement = async () => {
        try {
            const response = await fetch("http://localhost:8080/api/cart/decrease", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${sessionStorage.getItem("Auth token")}`,
                },
                body: JSON.stringify({ productId: product.product }),
            });

            if (response.ok) {
                const updatedCart = await response.json();
                updateCart(updatedCart.items);
            }
        } catch (err) {
            console.error("Error updating cart:", err);
        }
    };

    const handleRemove = async () => {
        try {
            const response = await fetch(`http://localhost:8080/api/cart/remove-item/${product.product}`, {
                method: "DELETE",
                headers: {
                    Authorization: `Bearer ${sessionStorage.getItem("Auth token")}`,
                },
            });

            if (response.ok) {
                const updatedCart = await response.json();
                updateCart(updatedCart.items);
            }
        } catch (err) {
            console.error("Error removing item:", err);
        }
    };


    return (
        <div className="flex p-1 sm:p-2 border-b border-b-gray-200">
            <div className="product-image mr-2 border border-grey-200 rounded-lg w-full sm:w-1/3">
                <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
            </div>
            <div className="product-info">
                <h3>{product.name}</h3>
                <p className="text-gray-600">{product.description}</p>
            </div>
            <div className="product-price-qt flex flex-col items-center justify-center">
                <div className="price">{`${product.price}$`}</div>
                <div className="quantity flex">
                    <button className="p-1" disabled={product.amount <= 1} onClick={handleDecrement}>-</button>
                    <span className="p-1">{product.amount}</span>
                    <button className="p-1" onClick={handleIncrement}>+</button>
                </div>
            </div>
            <div className="product-price-qt flex flex-col items-center justify-center">
                <div className="price">{`${product.price}$`}</div>
                <button className="bg-red-500 text-white px-2 py-1 rounded mt-2" onClick={handleRemove}>
                    Remove
                </button>
            </div>
        </div>
    );
};
