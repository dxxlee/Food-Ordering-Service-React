import { useForm } from "react-hook-form";
import Button from "./elements/Button";
import { ReactComponent as ArrowRightSvg } from "../assets/icons/arrow-right-long-svgrepo-com.svg";
import { useDispatch } from "react-redux";
import { setAddress } from "../stores/userInfo/addressSlice";
import { useState } from "react";

export const AddressForm = ({ onTabSwitch }) => {
    const { register, handleSubmit, formState: { errors }} = useForm();
    const dispatch = useDispatch();
    const [leaveAtDoor, setLeaveAtDoor] = useState(false);

    const onSubmit = (data) => {
        dispatch(setAddress({ ...data, leaveAtDoor }));
        onTabSwitch("Payment");
    };

    return (
        <form className="md:w-2/3 md:mx-auto px-3 pt-1" onSubmit={handleSubmit(onSubmit)}>
            <h3 className="pt-4 text-2xl md:text-center">Delivery Information</h3>

            {/* Имя получателя */}
            <div className="mb-4">
                <label className="block mb-2 text-sm font-bold text-gray-700" htmlFor="recipientName">Recipient's Name</label>
                <input 
                    {...register("recipientName", { required: true })}
                    className="w-full px-3 py-2 text-sm border rounded shadow focus:outline-none focus:shadow-outline"
                    id="recipientName"
                    type="text"
                    placeholder="Full Name"
                />
                {errors.recipientName && <span className="text-red-500">This field is required</span>}
            </div>

            {/* Телефон */}
            <div className="mb-4">
                <label className="block mb-2 text-sm font-bold text-gray-700" htmlFor="phone">Phone Number</label>
                <input 
                    {...register("phone", { required: true })}
                    className="w-full px-3 py-2 text-sm border rounded shadow focus:outline-none focus:shadow-outline"
                    id="phone"
                    type="tel"
                    placeholder="Your phone number"
                />
                {errors.phone && <span className="text-red-500">This field is required</span>}
            </div>

            {/* Адрес */}
            <div className="mb-4">
                <label className="block mb-2 text-sm font-bold text-gray-700" htmlFor="address">Street Address</label>
                <input 
                    {...register("address", { required: true })}
                    className="w-full px-3 py-2 text-sm border rounded shadow focus:outline-none focus:shadow-outline"
                    id="address"
                    type="text"
                    placeholder="Street Address"
                />
                {errors.address && <span className="text-red-500">This field is required</span>}
            </div>

            {/* Квартира / Дом */}
            <div className="mb-4">
                <label className="block mb-2 text-sm font-bold text-gray-700" htmlFor="apartment">Apartment / House</label>
                <input 
                    {...register("apartment")}
                    className="w-full px-3 py-2 text-sm border rounded shadow focus:outline-none focus:shadow-outline"
                    id="apartment"
                    type="text"
                    placeholder="Apartment / House (Optional)"
                />
            </div>

            {/* Город */}
            <div className="mb-4">
                <label className="block mb-2 text-sm font-bold text-gray-700" htmlFor="city">City</label>
                <input 
                    {...register("city", { required: true })}
                    className="w-full px-3 py-2 text-sm border rounded shadow focus:outline-none focus:shadow-outline"
                    id="city"
                    type="text"
                    placeholder="City"
                />
                {errors.city && <span className="text-red-500">This field is required</span>}
            </div>

            {/* Оставить у двери? */}
            <div className="mb-4 flex items-center">
                <input 
                    type="checkbox" 
                    id="leaveAtDoor" 
                    checked={leaveAtDoor} 
                    onChange={() => setLeaveAtDoor(!leaveAtDoor)} 
                    className="mr-2"
                />
                <label htmlFor="leaveAtDoor" className="text-sm text-gray-700">Leave at the door?</label>
            </div>

            <div className="flex justify-end p-2">
                <Button variant="dark" className="flex items-center" type="submit">
                    <span className="mr-1">Next</span>
                    <ArrowRightSvg />
                </Button>
            </div>
        </form>
    );
};
