import aboutImage from "../assets/images/about-image.png";

import React from 'react';
import { GoogleMap, LoadScript, Marker } from '@react-google-maps/api';

const mapContainerStyle = {
    width: '100%',
    height: '400px',
};

const center = {
    lat: 51.090573207373595, 
    lng: 71.4259698820672,
};

export const About = () => {
    return (
        <div className="container mx-auto p-4 text-black bg-white">
            <div className="bg-white">
            <div className="p-24 grid grid-cols-2">
                <div className="">
                    <h2 className="text-2xl font-medium">About Us</h2>
                    <p className="text-lg">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt,
                    beatae! Doloribus fuga aperiam magni ipsum repellat voluptates
                    itaque error, atque, exercitationem fugit ab, modi ut voluptatum
                    sequi ad eum! Rerum! Lorem ipsum dolor sit amet consectetur
                    adipisicing elit. Minus quia suscipit deserunt, neque nemo veniam
                    adipisci deleniti culpa dolor dolores omnis, rem veritatis assumenda
                    eaque dignissimos ut, nam debitis numquam!
                    </p>
                </div>
                <div className="flex items-center justify-center">
                    <img src={aboutImage} alt="" className="w-[400px] h-[400px] object-cover" />
                </div>
            </div>
        </div>

            <h2 className="text-xl font-bold mb-4">Our locations</h2>
            <p className="mb-4">
                Welcome to our food ordering service! We aim to bring you the best culinary experience.
            </p>
            <div>
                <LoadScript googleMapsApiKey="AIzaSyBCvngeCiJFqxk9dULIffo_C9nE-WY-UfU">
                    <GoogleMap
                        mapContainerStyle={mapContainerStyle}
                        center={center}
                        zoom={12}
                    >
                        <Marker position={center} />
                    </GoogleMap>
                </LoadScript>
            </div>
        </div>
    );
};


