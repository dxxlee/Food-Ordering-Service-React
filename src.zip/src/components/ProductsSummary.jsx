import { ProductSummaryCard } from "./ProductSummaryCard";

export const ProductsSummary = ({ cart, updateCart }) => {

    const handleClearCart = async () => {
        try {
            const response = await fetch("http://localhost:8080/api/cart/clear", {
                method: "DELETE",
                headers: {
                    Authorization: `Bearer ${sessionStorage.getItem("Auth token")}`,
                },
            });

            if (response.ok) {
                updateCart([]); // Очищаем корзину на фронте
            }
        } catch (err) {
            console.error("Error clearing cart:", err);
        }
    };
    
    return (
        // <div className="flex flex-col">
        //     {cart.length > 0 && (
        //         <button className="bg-red-600 text-white px-4 py-2 rounded mb-2" onClick={handleClearCart}>
        //             Clear Cart
        //         </button>
        //     )}
        // </div>

        <div className="flex flex-col">
            {cart.length > 0 && (
                <button className="bg-red-600 text-white px-4 py-2 rounded mb-2" onClick={handleClearCart}>
                    Clear Cart
                </button>
            )}
            {cart && cart.map((product, index) => (
                <ProductSummaryCard product={product} key={index} updateCart={updateCart} />
            ))}
        </div>
    );
};


// import { useSelector } from "react-redux";
// import { cartProducts } from "../stores/cart/cartSlice";
// import { ProductsSummaryCard } from "./ProductSummaryCard";

// export const ProductsSummary = ({ updateCart }) => {
//     const cart = useSelector(cartProducts);

//     const handleClearCart = async () => {
//         try {
//             const response = await fetch("http://localhost:8080/api/cart/clear", {
//                 method: "DELETE",
//                 headers: {
//                     Authorization: `Bearer ${sessionStorage.getItem("Auth token")}`,
//                 },
//             });

//             if (response.ok) {
//                 updateCart([]); // Очищаем корзину на фронте
//             }
//         } catch (err) {
//             console.error("Error clearing cart:", err);
//         }
//     };

//     return (
//         <div className="flex flex-col">
//             {cart.length > 0 && (
//                 <button className="bg-red-600 text-white px-4 py-2 rounded mb-2" onClick={handleClearCart}>
//                     Clear Cart
//                 </button>
//             )}
//             {cart.map((product, index) => (
//                 <ProductsSummaryCard product={product} key={index} updateCart={updateCart} />
//             ))}
//         </div>
//     );
// };

