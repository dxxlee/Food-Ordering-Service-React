import { useEffect, useState } from "react";

const Orders = () => {
    const [orders, setOrders] = useState([]);

    const fetchOrders = async () => {
        try {
            const response = await fetch("http://localhost:8080/api/orders", {
                headers: { Authorization: `Bearer ${sessionStorage.getItem("Auth token")}` },
            });

            if (response.ok) {
                const data = await response.json();
                setOrders(data);
            } else {
                console.error("Failed to fetch orders");
            }
        } catch (err) {
            console.error("Error fetching orders:", err);
        }
    };

    useEffect(() => {
        fetchOrders();
    }, []);

    return (
        <div className="container mx-auto p-6 text-white">
            <h1 className="text-3xl font-bold mb-6 text-center">Your Orders</h1>
            {orders.length === 0 ? (
                <p className="text-lg font-semibold text-center">No orders found.</p>
            ) : (
                <div className="space-y-6">
                    {orders.map((order) => (
                        <div key={order._id} className="border border-gray-700 p-6 rounded-lg shadow-lg bg-gray-900">
                            <div className="mb-4">
                                <p className="text-lg font-semibold">Order ID: <span className="text-yellow-400">{order._id}</span></p>
                                <p className="text-md">Total Price: <span className="font-bold">${order.totalPrice.toFixed(2)}</span></p>
                                <p className="text-sm text-gray-400">Delivery Address: {order.shippingAddress.city}, {order.shippingAddress.address}, {order.shippingAddress.apartment}</p>
                                <p className="text-sm text-gray-400">Contact Information: {order.shippingAddress.phone}, {order.shippingAddress.recipientName}</p>
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                                {order.orderItems.map((item) => (
                                    <div key={item._id} className="bg-gray-800 p-4 rounded-lg shadow-md">
                                        {item.product ? ( 
                                            <>
                                                <div className="w-full h-40 flex justify-center">
                                                    <img 
                                                        src={item.product.imageUrl} 
                                                        alt={item.product.name} 
                                                        className="max-h-full object-cover rounded-lg"
                                                    />
                                                </div>
                                                <div className="mt-2 text-center">
                                                    <p className="text-lg font-semibold">{item.product.name}</p>
                                                    <p className="text-sm text-gray-400">Amount: {item.amount}</p>
                                                    <p className="font-bold">${item.product.price}</p>
                                                </div>
                                            </>
                                        ) : (
                                            <p className="text-red-500 text-center">Product not available</p>
                                        )}
                                    </div>
                                ))}
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default Orders;
